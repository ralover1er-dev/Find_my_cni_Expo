import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  StyleSheet,
  ActivityIndicator,
  Modal,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { supabase, Declaration } from '../lib/supabase';

export default function SearchScreen({ route, navigation }: any) {
  const initialQuery = route?.params?.initialQuery || '';
  const [searchTerm, setSearchTerm] = useState(initialQuery);
  const [results, setResults] = useState<Declaration[]>([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);
  const [selectedItem, setSelectedItem] = useState<Declaration | null>(null);

  useEffect(() => {
    if (initialQuery) {
      handleSearch(initialQuery);
    }
  }, [initialQuery]);

  // CORRIGÉ: Recherche filtrée STRICTEMENT sur status = 'approved'
  const handleSearch = async (termToSearch: string = searchTerm) => {
    if (!termToSearch.trim()) {
      Alert.alert('Champ vide', 'Veuillez entrer un nom ou des chiffres à rechercher.');
      return;
    }

    try {
      setLoading(true);
      setSearched(true);

      const trimmed = termToSearch.trim();

      // Construction de la requête avec filtre status='approved' obligatoire
      let query = supabase
        .from('declarations')
        .select('*')
        .eq('status', 'approved'); // CORRIGÉ: Seuls les enregistrements approuvés sont visibles

      // Recherche par nom (ilike) ou par 4 derniers chiffres
      if (/^\d+$/.test(trimmed)) {
        // C'est un numéro
        query = query.or(`cni_last_4_digits.ilike.%${trimmed}%,full_name.ilike.%${trimmed}%`);
      } else {
        // C'est un texte / nom
        query = query.ilike('full_name', `%${trimmed}%`);
      }

      const { data, error } = await query.order('created_at', { ascending: false });

      if (error) {
        console.error('Erreur recherche:', error.message);
        Alert.alert('Erreur', 'Impossible de récupérer les résultats.');
      } else {
        setResults(data || []);
      }
    } catch (err: any) {
      console.error(err);
      Alert.alert('Erreur', err.message || 'Une erreur est survenue.');
    } finally {
      setLoading(false);
    }
  };

  const renderItem = ({ item }: { item: Declaration }) => (
    <TouchableOpacity
      style={styles.card}
      activeOpacity={0.85}
      onPress={() => setSelectedItem(item)}
    >
      <View style={styles.cardHeader}>
        <View style={styles.badgeSuccess}>
          <Ionicons name="checkmark-circle" size={14} color="#16A34A" />
          <Text style={styles.badgeSuccessText}>Trouvée & Vérifiée</Text>
        </View>
        <Text style={styles.dateText}>
          {item.created_at ? new Date(item.created_at).toLocaleDateString('fr-FR') : ''}
        </Text>
      </View>

      <Text style={styles.cardName}>{item.full_name}</Text>

      <View style={styles.detailsRow}>
        <View style={styles.detailTag}>
          <Ionicons name="location-outline" size={14} color="#0F4C81" />
          <Text style={styles.detailText}>{item.location || 'Cameroun'}</Text>
        </View>
        {item.cni_last_4_digits && (
          <View style={styles.detailTag}>
            <Ionicons name="card-outline" size={14} color="#0F4C81" />
            <Text style={styles.detailText}>Finissant par: {item.cni_last_4_digits}</Text>
          </View>
        )}
      </View>

      {item.description ? (
        <Text style={styles.descText} numberOfLines={2}>
          {item.description}
        </Text>
      ) : null}

      <View style={styles.claimButton}>
        <Text style={styles.claimButtonText}>Voir les détails de récupération →</Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      {/* Header & Barre de recherche */}
      <View style={styles.searchSection}>
        <Text style={styles.screenTitle}>Rechercher une CNI</Text>
        <Text style={styles.screenSubtitle}>
          Trouvez instantanément si votre CNI a été retrouvée et enregistrée par un citoyen ou commissariat.
        </Text>

        <View style={styles.inputContainer}>
          <Ionicons name="search" size={20} color="#64748B" style={styles.inputIcon} />
          <TextInput
            style={styles.input}
            placeholder="Ex: Nguema, Fouda ou 4 derniers chiffres"
            placeholderTextColor="#94A3B8"
            value={searchTerm}
            onChangeText={setSearchTerm}
            onSubmitEditing={() => handleSearch()}
            returnKeyType="search"
          />
          {searchTerm.length > 0 && (
            <TouchableOpacity onPress={() => setSearchTerm('')} style={styles.clearBtn}>
              <Ionicons name="close-circle" size={18} color="#94A3B8" />
            </TouchableOpacity>
          )}
        </View>

        <TouchableOpacity
          style={styles.btnSearch}
          onPress={() => handleSearch()}
          activeOpacity={0.8}
        >
          <Text style={styles.btnSearchText}>Lancer la recherche</Text>
        </TouchableOpacity>
      </View>

      {/* Résultats */}
      {loading ? (
        <View style={styles.centerContainer}>
          <ActivityIndicator size="large" color="#0F4C81" />
          <Text style={styles.loadingText}>Recherche dans la base de données...</Text>
        </View>
      ) : searched && results.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Ionicons name="search-outline" size={54} color="#CBD5E1" />
          <Text style={styles.emptyTitle}>Aucune CNI trouvée</Text>
          <Text style={styles.emptySubtitle}>
            Aucune CNI approuvée ne correspond à "{searchTerm}". Si vous venez de la perdre, déposez une déclaration de perte dès maintenant.
          </Text>
          <TouchableOpacity
            style={styles.btnDeclareLost}
            onPress={() => navigation.navigate('LostForm')}
          >
            <Text style={styles.btnDeclareLostText}>Déclarer ma CNI perdue</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <FlatList
          data={results}
          keyExtractor={(item, index) => item.id || index.toString()}
          renderItem={renderItem}
          contentContainerStyle={styles.listContent}
          ListHeaderComponent={
            searched ? (
              <Text style={styles.resultCountText}>
                {results.length} CNI correspondante(s) trouvée(s)
              </Text>
            ) : null
          }
        />
      )}

      {/* Modal Détails & Contact */}
      <Modal visible={!!selectedItem} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Détails de la CNI</Text>
              <TouchableOpacity onPress={() => setSelectedItem(null)}>
                <Ionicons name="close" size={24} color="#64748B" />
              </TouchableOpacity>
            </View>

            {selectedItem && (
              <View style={styles.modalBody}>
                <View style={styles.modalBadge}>
                  <Ionicons name="checkmark-done" size={16} color="#16A34A" />
                  <Text style={styles.modalBadgeText}>Status : Vérifiée & Approuvée</Text>
                </View>

                <Text style={styles.modalLabel}>Nom complet :</Text>
                <Text style={styles.modalValue}>{selectedItem.full_name}</Text>

                {selectedItem.cni_last_4_digits && (
                  <>
                    <Text style={styles.modalLabel}>4 derniers chiffres :</Text>
                    <Text style={styles.modalValue}>...{selectedItem.cni_last_4_digits}</Text>
                  </>
                )}

                <Text style={styles.modalLabel}>Lieu où elle a été déposée :</Text>
                <Text style={styles.modalValue}>{selectedItem.location || 'Non précisé'}</Text>

                {selectedItem.contact_phone && (
                  <>
                    <Text style={styles.modalLabel}>Contact / Récupération :</Text>
                    <Text style={[styles.modalValue, { color: '#0F4C81', fontWeight: 'bold' }]}>
                      {selectedItem.contact_phone}
                    </Text>
                  </>
                )}

                {selectedItem.description && (
                  <>
                    <Text style={styles.modalLabel}>Note complémentaire :</Text>
                    <Text style={styles.modalValue}>{selectedItem.description}</Text>
                  </>
                )}

                <TouchableOpacity
                  style={styles.modalCloseBtn}
                  onPress={() => setSelectedItem(null)}
                >
                  <Text style={styles.modalCloseBtnText}>Fermer</Text>
                </TouchableOpacity>
              </View>
            )}
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  searchSection: {
    backgroundColor: '#FFFFFF',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0',
  },
  screenTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#0F172A',
    marginBottom: 4,
  },
  screenSubtitle: {
    fontSize: 13,
    color: '#64748B',
    marginBottom: 16,
    lineHeight: 18,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F1F5F9',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#CBD5E1',
    paddingHorizontal: 12,
    marginBottom: 12,
  },
  inputIcon: {
    marginRight: 8,
  },
  input: {
    flex: 1,
    paddingVertical: 10,
    fontSize: 15,
    color: '#1E293B',
  },
  clearBtn: {
    padding: 4,
  },
  btnSearch: {
    backgroundColor: '#0F4C81',
    paddingVertical: 12,
    borderRadius: 12,
    alignItems: 'center',
  },
  btnSearchText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 15,
  },
  listContent: {
    padding: 16,
  },
  resultCountText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#64748B',
    marginBottom: 12,
  },
  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    padding: 16,
    marginBottom: 14,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 2,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  badgeSuccess: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#DCFCE7',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 10,
    gap: 4,
  },
  badgeSuccessText: {
    color: '#16A34A',
    fontSize: 11,
    fontWeight: 'bold',
  },
  dateText: {
    fontSize: 12,
    color: '#94A3B8',
  },
  cardName: {
    fontSize: 17,
    fontWeight: 'bold',
    color: '#0F172A',
    marginBottom: 8,
  },
  detailsRow: {
    flexDirection: 'row',
    gap: 8,
    flexWrap: 'wrap',
    marginBottom: 8,
  },
  detailTag: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#EFF6FF',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
    gap: 4,
  },
  detailText: {
    fontSize: 12,
    color: '#0F4C81',
    fontWeight: '500',
  },
  descText: {
    fontSize: 13,
    color: '#64748B',
    marginBottom: 10,
  },
  claimButton: {
    borderTopWidth: 1,
    borderTopColor: '#F1F5F9',
    paddingTop: 10,
    marginTop: 4,
  },
  claimButtonText: {
    color: '#0F4C81',
    fontWeight: '600',
    fontSize: 13,
  },
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  loadingText: {
    marginTop: 12,
    color: '#64748B',
    fontSize: 14,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 30,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1E293B',
    marginTop: 12,
    marginBottom: 6,
  },
  emptySubtitle: {
    fontSize: 13,
    color: '#64748B',
    textAlign: 'center',
    lineHeight: 18,
    marginBottom: 20,
  },
  btnDeclareLost: {
    backgroundColor: '#DC2626',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 12,
  },
  btnDeclareLostText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 14,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  modalCard: {
    backgroundColor: '#FFFFFF',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    padding: 24,
    maxHeight: '80%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0F172A',
  },
  modalBody: {
    gap: 8,
  },
  modalBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#DCFCE7',
    alignSelf: 'flex-start',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
    gap: 6,
    marginBottom: 10,
  },
  modalBadgeText: {
    color: '#16A34A',
    fontWeight: '700',
    fontSize: 12,
  },
  modalLabel: {
    fontSize: 12,
    color: '#64748B',
    fontWeight: '600',
    marginTop: 4,
  },
  modalValue: {
    fontSize: 15,
    color: '#1E293B',
    fontWeight: '500',
  },
  modalCloseBtn: {
    backgroundColor: '#0F4C81',
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 20,
  },
  modalCloseBtnText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 15,
  },
});
