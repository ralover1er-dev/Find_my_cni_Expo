import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  RefreshControl,
  ActivityIndicator,
  TextInput,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { supabase, Declaration } from '../lib/supabase';

export default function HomeScreen({ navigation }: any) {
  const [approvedDeclarations, setApprovedDeclarations] = useState<Declaration[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [quickSearch, setQuickSearch] = useState('');

  // CORRIGÉ: Charge uniquement les CNI avec status='approved'
  const fetchApprovedDeclarations = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('declarations')
        .select('*')
        .eq('status', 'approved') // CORRIGÉ: Filtre strict sur status='approved'
        .order('created_at', { ascending: false })
        .limit(10);

      if (error) {
        console.error('Erreur chargement CNI approuvées:', error.message);
      } else {
        setApprovedDeclarations(data || []);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchApprovedDeclarations();
  }, []);

  const onRefresh = () => {
    setRefreshing(true);
    fetchApprovedDeclarations();
  };

  const handleQuickSearch = () => {
    if (quickSearch.trim()) {
      navigation.navigate('Search', { initialQuery: quickSearch.trim() });
    } else {
      navigation.navigate('Search');
    }
  };

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.contentContainer}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={['#0F4C81']} />}
    >
      {/* Header Banner */}
      <View style={styles.header}>
        <View style={styles.badgeCameroon}>
          <Text style={styles.badgeText}>🇨🇲 SERVICE CITOYEN CNI</Text>
        </View>
        <Text style={styles.headerTitle}>Find My CNI</Text>
        <Text style={styles.headerSubtitle}>
          Retrouvez ou restituez une Carte Nationale d'Identité au Cameroun en toute sécurité.
        </Text>

        {/* Barre de recherche rapide */}
        <View style={styles.searchBarContainer}>
          <Ionicons name="search" size={20} color="#666" style={styles.searchIcon} />
          <TextInput
            style={styles.searchInput}
            placeholder="Nom complet ou 4 derniers chiffres..."
            placeholderTextColor="#888"
            value={quickSearch}
            onChangeText={setQuickSearch}
            onSubmitEditing={handleQuickSearch}
            returnKeyType="search"
          />
          <TouchableOpacity style={styles.searchButton} onPress={handleQuickSearch}>
            <Text style={styles.searchButtonText}>Chercher</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Cartes d'Actions Principales */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Que souhaitez-vous faire ?</Text>
        <View style={styles.actionGrid}>
          {/* Action Perte */}
          <TouchableOpacity
            style={[styles.actionCard, styles.lostCard]}
            activeOpacity={0.85}
            onPress={() => navigation.navigate('LostForm')}
          >
            <View style={[styles.iconCircle, { backgroundColor: '#FEE2E2' }]}>
              <Ionicons name="alert-circle" size={28} color="#DC2626" />
            </View>
            <Text style={styles.actionCardTitle}>J'ai perdu ma CNI</Text>
            <Text style={styles.actionCardDesc}>
              Déclarez votre perte et recevez une alerte dès qu'elle est retrouvée.
            </Text>
            <View style={styles.actionFooter}>
              <Text style={[styles.actionBtnText, { color: '#DC2626' }]}>Déclarer perte →</Text>
            </View>
          </TouchableOpacity>

          {/* Action Trouvé */}
          <TouchableOpacity
            style={[styles.actionCard, styles.foundCard]}
            activeOpacity={0.85}
            onPress={() => navigation.navigate('FoundForm')}
          >
            <View style={[styles.iconCircle, { backgroundColor: '#DCFCE7' }]}>
              <Ionicons name="shield-checkmark" size={28} color="#16A34A" />
            </View>
            <Text style={styles.actionCardTitle}>J'ai trouvé une CNI</Text>
            <Text style={styles.actionCardDesc}>
              Photographiez et enregistrez une CNI pour aider son titulaire.
            </Text>
            <View style={styles.actionFooter}>
              <Text style={[styles.actionBtnText, { color: '#16A34A' }]}>Enregistrer CNI →</Text>
            </View>
          </TouchableOpacity>
        </View>
      </View>

      {/* Liste des CNI Récemment Approuvées & Disponibles */}
      <View style={styles.section}>
        <View style={styles.sectionHeaderRow}>
          <Text style={styles.sectionTitle}>Dernières CNI trouvées & vérifiées</Text>
          <TouchableOpacity onPress={() => navigation.navigate('Search')}>
            <Text style={styles.seeAllText}>Tout voir</Text>
          </TouchableOpacity>
        </View>

        {loading ? (
          <ActivityIndicator size="small" color="#0F4C81" style={{ marginVertical: 20 }} />
        ) : approvedDeclarations.length === 0 ? (
          <View style={styles.emptyCard}>
            <Ionicons name="information-circle-outline" size={32} color="#94A3B8" />
            <Text style={styles.emptyText}>Aucune déclaration approuvée récente pour l'instant.</Text>
          </View>
        ) : (
          approvedDeclarations.map((item) => (
            <View key={item.id} style={styles.cniItemCard}>
              <View style={styles.cniItemHeader}>
                <View style={styles.cniBadgeApproved}>
                  <Ionicons name="checkmark-circle" size={14} color="#16A34A" />
                  <Text style={styles.cniBadgeText}>Vérifiée</Text>
                </View>
                <Text style={styles.cniDate}>
                  {item.created_at ? new Date(item.created_at).toLocaleDateString('fr-FR') : ''}
                </Text>
              </View>

              <Text style={styles.cniName}>{item.full_name}</Text>
              
              <View style={styles.cniMetaRow}>
                <View style={styles.metaBadge}>
                  <Ionicons name="location-outline" size={14} color="#475569" />
                  <Text style={styles.metaText}>{item.location || 'Cameroun'}</Text>
                </View>
                {item.cni_last_4_digits && (
                  <View style={styles.metaBadge}>
                    <Ionicons name="card-outline" size={14} color="#475569" />
                    <Text style={styles.metaText}>N° ...{item.cni_last_4_digits}</Text>
                  </View>
                )}
              </View>

              {item.description ? (
                <Text style={styles.cniDesc} numberOfLines={2}>
                  {item.description}
                </Text>
              ) : null}
            </View>
          ))
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  contentContainer: {
    paddingBottom: 40,
  },
  header: {
    backgroundColor: '#0F4C81',
    paddingTop: 24,
    paddingBottom: 28,
    paddingHorizontal: 20,
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
  },
  badgeCameroon: {
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    alignSelf: 'flex-start',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 20,
    marginBottom: 10,
  },
  badgeText: {
    color: '#FFF',
    fontSize: 12,
    fontWeight: '700',
    letterSpacing: 0.5,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 6,
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#E2E8F0',
    lineHeight: 20,
    marginBottom: 20,
  },
  searchBarContainer: {
    flexDirection: 'row',
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    paddingHorizontal: 12,
    paddingVertical: 6,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 3,
  },
  searchIcon: {
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 14,
    color: '#1E293B',
    paddingVertical: 8,
  },
  searchButton: {
    backgroundColor: '#0F4C81',
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 10,
  },
  searchButtonText: {
    color: '#FFF',
    fontWeight: '600',
    fontSize: 13,
  },
  section: {
    paddingHorizontal: 20,
    marginTop: 24,
  },
  sectionHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 14,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#0F172A',
    marginBottom: 14,
  },
  seeAllText: {
    color: '#0F4C81',
    fontWeight: '600',
    fontSize: 14,
  },
  actionGrid: {
    gap: 14,
  },
  actionCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    padding: 18,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  lostCard: {
    borderLeftWidth: 5,
    borderLeftColor: '#DC2626',
  },
  foundCard: {
    borderLeftWidth: 5,
    borderLeftColor: '#16A34A',
  },
  iconCircle: {
    width: 50,
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  actionCardTitle: {
    fontSize: 17,
    fontWeight: '700',
    color: '#1E293B',
    marginBottom: 4,
  },
  actionCardDesc: {
    fontSize: 13,
    color: '#64748B',
    lineHeight: 18,
    marginBottom: 12,
  },
  actionFooter: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
  },
  actionBtnText: {
    fontWeight: '700',
    fontSize: 14,
  },
  emptyCard: {
    backgroundColor: '#FFF',
    padding: 24,
    borderRadius: 14,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  emptyText: {
    color: '#64748B',
    fontSize: 14,
    marginTop: 8,
    textAlign: 'center',
  },
  cniItemCard: {
    backgroundColor: '#FFF',
    borderRadius: 14,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  cniItemHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  cniBadgeApproved: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#DCFCE7',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 12,
    gap: 4,
  },
  cniBadgeText: {
    color: '#16A34A',
    fontSize: 11,
    fontWeight: '700',
  },
  cniDate: {
    fontSize: 12,
    color: '#94A3B8',
  },
  cniName: {
    fontSize: 16,
    fontWeight: '700',
    color: '#0F172A',
    marginBottom: 8,
  },
  cniMetaRow: {
    flexDirection: 'row',
    gap: 10,
    marginBottom: 6,
  },
  metaBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F1F5F9',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
    gap: 4,
  },
  metaText: {
    fontSize: 12,
    color: '#475569',
  },
  cniDesc: {
    fontSize: 13,
    color: '#64748B',
    marginTop: 4,
  },
});
