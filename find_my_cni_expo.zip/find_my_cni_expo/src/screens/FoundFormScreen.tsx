import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  Image,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { supabase, uploadImageToSupabase, Declaration } from '../lib/supabase';

export default function FoundFormScreen({ navigation }: any) {
  const [fullName, setFullName] = useState('');
  const [dob, setDob] = useState('');
  const [last4Digits, setLast4Digits] = useState('');
  const [location, setLocation] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [description, setDescription] = useState('');
  const [photoUri, setPhotoUri] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const pickImage = async () => {
    try {
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission requise', 'Autorisez l’accès aux photos pour joindre la CNI trouvée.');
        return;
      }

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        quality: 0.7,
      });

      if (!result.canceled && result.assets && result.assets[0].uri) {
        setPhotoUri(result.assets[0].uri);
      }
    } catch (e: any) {
      console.error(e);
      Alert.alert('Erreur', 'Impossible de sélectionner l’image.');
    }
  };

  const takePhoto = async () => {
    try {
      const { status } = await ImagePicker.requestCameraPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission requise', 'Autorisez l’appareil photo pour capturer la CNI.');
        return;
      }

      const result = await ImagePicker.launchCameraAsync({
        allowsEditing: true,
        quality: 0.7,
      });

      if (!result.canceled && result.assets && result.assets[0].uri) {
        setPhotoUri(result.assets[0].uri);
      }
    } catch (e: any) {
      console.error(e);
      Alert.alert('Erreur', 'Impossible de prendre la photo.');
    }
  };

  const handleSubmit = async () => {
    if (!fullName.trim()) {
      Alert.alert('Champs obligatoires', 'Veuillez saisir le Nom inscrit sur la CNI trouvée.');
      return;
    }
    if (!location.trim()) {
      Alert.alert('Champs obligatoires', 'Veuillez préciser où la CNI a été trouvée ou déposée.');
      return;
    }
    if (!contactPhone.trim()) {
      Alert.alert('Champs obligatoires', 'Veuillez fournir un numéro pour joindre le détenteur actuel.');
      return;
    }

    try {
      setLoading(true);

      // 1. Utilisateur connecté
      const { data: userData } = await supabase.auth.getUser();
      const currentUserId = userData.user?.id || 'anonymous_finder';

      let uploadedPhotoUrl: string | null = null;

      // CORRIGÉ: 2. Upload strict dans le bucket 'cni-photos'/user_id/
      if (photoUri) {
        uploadedPhotoUrl = await uploadImageToSupabase(photoUri, currentUserId);
      }

      // CORRIGÉ: 3. Insertion avec status='pending'
      const newDeclaration: Declaration = {
        user_id: userData.user?.id || undefined,
        type: 'found',
        full_name: fullName.trim(),
        date_of_birth: dob.trim() || undefined,
        cni_last_4_digits: last4Digits.trim() || undefined,
        location: location.trim(),
        contact_phone: contactPhone.trim(),
        description: description.trim() || undefined,
        photo_url: uploadedPhotoUrl || undefined,
        status: 'pending', // CORRIGÉ: Statut en attente de validation
      };

      const { data, error } = await supabase
        .from('declarations')
        .insert([newDeclaration]);

      if (error) {
        console.error('Erreur enregistrement CNI trouvée:', error.message);
        Alert.alert('Erreur', `Échec: ${error.message}`);
      } else {
        Alert.alert(
          'CNI enregistrée !',
          'Merci pour votre geste citoyen ! La CNI est en cours de validation (statut pending) et apparaîtra dans les recherches dès son approbation.',
          [
            {
              text: 'OK',
              onPress: () => navigation.navigate('Home'),
            },
          ]
        );
      }
    } catch (err: any) {
      console.error(err);
      Alert.alert('Erreur', err.message || 'Une erreur est survenue.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.contentContainer}>
      <View style={styles.banner}>
        <Ionicons name="shield-checkmark" size={32} color="#16A34A" />
        <View style={{ flex: 1 }}>
          <Text style={styles.bannerTitle}>Enregistrer une CNI Trouvée</Text>
          <Text style={styles.bannerSubtitle}>
            Aidez un concitoyen à retrouver sa pièce d’identité en toute discrétion.
          </Text>
        </View>
      </View>

      <View style={styles.card}>
        <Text style={styles.label}>Nom complet lisible sur la CNI *</Text>
        <TextInput
          style={styles.input}
          placeholder="Ex: ABESSOLO EKANI Marie"
          placeholderTextColor="#94A3B8"
          value={fullName}
          onChangeText={setFullName}
        />

        <Text style={styles.label}>Date de naissance sur la CNI</Text>
        <TextInput
          style={styles.input}
          placeholder="Ex: 22/11/1988"
          placeholderTextColor="#94A3B8"
          value={dob}
          onChangeText={setDob}
        />

        <Text style={styles.label}>4 derniers chiffres du N° de CNI</Text>
        <TextInput
          style={styles.input}
          placeholder="Ex: 8520"
          placeholderTextColor="#94A3B8"
          keyboardType="numeric"
          maxLength={4}
          value={last4Digits}
          onChangeText={setLast4Digits}
        />

        <Text style={styles.label}>Lieu où elle a été trouvée ou déposée *</Text>
        <TextInput
          style={styles.input}
          placeholder="Ex: Douala - Akwa (Commissariat 1er ou chez M. X)"
          placeholderTextColor="#94A3B8"
          value={location}
          onChangeText={setLocation}
        />

        <Text style={styles.label}>Téléphone du contact / gardien *</Text>
        <TextInput
          style={styles.input}
          placeholder="Ex: +237 6YY YY YY YY"
          placeholderTextColor="#94A3B8"
          keyboardType="phone-pad"
          value={contactPhone}
          onChangeText={setContactPhone}
        />

        <Text style={styles.label}>Informations de remise</Text>
        <TextInput
          style={[styles.input, styles.textArea]}
          placeholder="Conditions de retrait (présenter un justificatif, récépissé, etc.)..."
          placeholderTextColor="#94A3B8"
          multiline
          numberOfLines={3}
          value={description}
          onChangeText={setDescription}
        />

        {/* Upload Photo CNI */}
        <Text style={styles.label}>Photo de la CNI trouvée (Recommandé)</Text>
        <View style={styles.photoActions}>
          <TouchableOpacity style={styles.photoBtn} onPress={takePhoto}>
            <Ionicons name="camera" size={18} color="#008751" />
            <Text style={styles.photoBtnText}>Appareil photo</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.photoBtn} onPress={pickImage}>
            <Ionicons name="images" size={18} color="#008751" />
            <Text style={styles.photoBtnText}>Galerie</Text>
          </TouchableOpacity>
        </View>

        {photoUri && (
          <View style={styles.previewContainer}>
            <Image source={{ uri: photoUri }} style={styles.previewImage} />
            <TouchableOpacity style={styles.removePhotoBtn} onPress={() => setPhotoUri(null)}>
              <Ionicons name="trash" size={16} color="#FFF" />
              <Text style={styles.removePhotoText}>Supprimer</Text>
            </TouchableOpacity>
          </View>
        )}

        <TouchableOpacity
          style={[styles.submitBtn, loading && styles.submitBtnDisabled]}
          onPress={handleSubmit}
          disabled={loading}
          activeOpacity={0.8}
        >
          {loading ? (
            <ActivityIndicator color="#FFFFFF" />
          ) : (
            <Text style={styles.submitBtnText}>Enregistrer la CNI trouvée</Text>
          )}
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  contentContainer: {
    padding: 16,
    paddingBottom: 40,
  },
  banner: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#DCFCE7',
    padding: 16,
    borderRadius: 14,
    marginBottom: 16,
    gap: 12,
  },
  bannerTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#166534',
  },
  bannerSubtitle: {
    fontSize: 12,
    color: '#15803D',
    marginTop: 2,
  },
  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  label: {
    fontSize: 13,
    fontWeight: '600',
    color: '#334155',
    marginBottom: 6,
    marginTop: 10,
  },
  input: {
    backgroundColor: '#F8FAFC',
    borderWidth: 1,
    borderColor: '#CBD5E1',
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 10,
    fontSize: 14,
    color: '#1E293B',
  },
  textArea: {
    minHeight: 70,
    textAlignVertical: 'top',
  },
  photoActions: {
    flexDirection: 'row',
    gap: 10,
    marginTop: 4,
    marginBottom: 10,
  },
  photoBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    backgroundColor: '#F0FDF4',
    paddingVertical: 10,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#BBF7D0',
  },
  photoBtnText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#16A34A',
  },
  previewContainer: {
    marginVertical: 12,
    alignItems: 'center',
  },
  previewImage: {
    width: '100%',
    height: 180,
    borderRadius: 10,
    resizeMode: 'cover',
  },
  removePhotoBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: '#DC2626',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
    marginTop: 8,
  },
  removePhotoText: {
    color: '#FFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  submitBtn: {
    backgroundColor: '#16A34A',
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 24,
  },
  submitBtnDisabled: {
    opacity: 0.6,
  },
  submitBtnText: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: 'bold',
  },
});
