import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { supabase, Declaration } from '../lib/supabase';

export default function ProfileScreen({ navigation }: any) {
  const [user, setUser] = useState<any>(null);
  const [myDeclarations, setMyDeclarations] = useState<Declaration[]>([]);
  const [loading, setLoading] = useState(true);

  const loadUserData = async () => {
    try {
      setLoading(true);
      const { data: authData } = await supabase.auth.getUser();
      setUser(authData.user);

      if (authData.user) {
        // Chargement des déclarations de cet utilisateur (tous statuts : pending, approved, rejected)
        const { data, error } = await supabase
          .from('declarations')
          .select('*')
          .eq('user_id', authData.user.id)
          .order('created_at', { ascending: false });

        if (error) {
          console.error('Erreur chargement mes déclarations:', error.message);
        } else {
          setMyDeclarations(data || []);
        }
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadUserData();
    const unsubscribe = navigation.addListener('focus', () => {
      loadUserData();
    });
    return unsubscribe;
  }, [navigation]);

  const handleSignOut = async () => {
    Alert.alert('Déconnexion', 'Voulez-vous vraiment vous déconnecter ?', [
      { text: 'Annuler', style: 'cancel' },
      {
        text: 'Déconnexion',
        style: 'destructive',
        onPress: async () => {
          await supabase.auth.signOut();
          setUser(null);
          setMyDeclarations([]);
        },
      },
    ]);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'approved':
        return {
          label: 'Approuvée',
          bgColor: '#DCFCE7',
          textColor: '#16A34A',
          icon: 'checkmark-circle',
        };
      case 'rejected':
        return {
          label: 'Refusée',
          bgColor: '#FEE2E2',
          textColor: '#DC2626',
          icon: 'close-circle',
        };
      case 'pending':
      default:
        return {
          label: 'En attente (Pending)',
          bgColor: '#FEF3C7',
          textColor: '#D97706',
          icon: 'time',
        };
    }
  };

  const renderDeclarationItem = ({ item }: { item: Declaration }) => {
    const badge = getStatusBadge(item.status);

    return (
      <View style={styles.declarationCard}>
        <View style={styles.cardHeader}>
          <View style={[styles.typeBadge, item.type === 'lost' ? styles.lostBadge : styles.foundBadge]}>
            <Text style={[styles.typeBadgeText, item.type === 'lost' ? styles.lostText : styles.foundText]}>
              {item.type === 'lost' ? 'Perte signalée' : 'CNI Trouvée'}
            </Text>
          </View>

          <View style={[styles.statusBadge, { backgroundColor: badge.bgColor }]}>
            <Ionicons name={badge.icon as any} size={12} color={badge.textColor} />
            <Text style={[styles.statusBadgeText, { color: badge.textColor }]}>{badge.label}</Text>
          </View>
        </View>

        <Text style={styles.itemTitle}>{item.full_name}</Text>
        <Text style={styles.itemSubtitle}>Lieu : {item.location || 'Non précisé'}</Text>
        {item.cni_last_4_digits && (
          <Text style={styles.itemSubtitle}>Finissant par : ...{item.cni_last_4_digits}</Text>
        )}
      </View>
    );
  };

  if (!user && !loading) {
    return (
      <View style={styles.notLoggedInContainer}>
        <Ionicons name="person-circle-outline" size={80} color="#94A3B8" />
        <Text style={styles.notLoggedInTitle}>Connectez-vous</Text>
        <Text style={styles.notLoggedInSubtitle}>
          Pour suivre vos déclarations de CNI et recevoir des notifications directes.
        </Text>
        <TouchableOpacity
          style={styles.signInBtn}
          onPress={() => navigation.navigate('Auth')}
        >
          <Text style={styles.signInBtnText}>Se connecter / S'inscrire</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* Profil Header */}
      <View style={styles.profileHeader}>
        <View style={styles.avatar}>
          <Text style={styles.avatarText}>
            {(user?.email?.[0] || 'U').toUpperCase()}
          </Text>
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.userName}>{user?.user_metadata?.full_name || 'Citoyen'}</Text>
          <Text style={styles.userEmail}>{user?.email}</Text>
        </View>
        <TouchableOpacity onPress={handleSignOut} style={styles.logoutBtn}>
          <Ionicons name="log-out-outline" size={22} color="#DC2626" />
        </TouchableOpacity>
      </View>

      {/* Mes Déclarations */}
      <View style={styles.listSection}>
        <Text style={styles.sectionHeading}>Mes déclarations enregistrées</Text>

        {loading ? (
          <ActivityIndicator size="small" color="#0F4C81" style={{ marginTop: 20 }} />
        ) : myDeclarations.length === 0 ? (
          <View style={styles.emptyCard}>
            <Ionicons name="document-text-outline" size={40} color="#CBD5E1" />
            <Text style={styles.emptyTitle}>Aucune déclaration</Text>
            <Text style={styles.emptySubtitle}>
              Vous n'avez pas encore déposé de déclaration de perte ou de trouvaille.
            </Text>
          </View>
        ) : (
          <FlatList
            data={myDeclarations}
            keyExtractor={(item, index) => item.id || index.toString()}
            renderItem={renderDeclarationItem}
            contentContainerStyle={{ paddingBottom: 24 }}
          />
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  notLoggedInContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 30,
    backgroundColor: '#F8FAFC',
  },
  notLoggedInTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0F172A',
    marginTop: 12,
  },
  notLoggedInSubtitle: {
    fontSize: 14,
    color: '#64748B',
    textAlign: 'center',
    marginTop: 6,
    marginBottom: 20,
    lineHeight: 20,
  },
  signInBtn: {
    backgroundColor: '#0F4C81',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 12,
  },
  signInBtnText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 15,
  },
  profileHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0',
    gap: 14,
  },
  avatar: {
    width: 54,
    height: 54,
    borderRadius: 27,
    backgroundColor: '#0F4C81',
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarText: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#FFF',
  },
  userName: {
    fontSize: 17,
    fontWeight: 'bold',
    color: '#0F172A',
  },
  userEmail: {
    fontSize: 13,
    color: '#64748B',
    marginTop: 2,
  },
  logoutBtn: {
    padding: 8,
    backgroundColor: '#FEE2E2',
    borderRadius: 10,
  },
  listSection: {
    flex: 1,
    padding: 16,
  },
  sectionHeading: {
    fontSize: 16,
    fontWeight: '700',
    color: '#0F172A',
    marginBottom: 12,
  },
  emptyCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    padding: 30,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#E2E8F0',
    marginTop: 20,
  },
  emptyTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1E293B',
    marginTop: 10,
  },
  emptySubtitle: {
    fontSize: 13,
    color: '#64748B',
    textAlign: 'center',
    marginTop: 4,
  },
  declarationCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  typeBadge: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 8,
  },
  lostBadge: {
    backgroundColor: '#FEE2E2',
  },
  foundBadge: {
    backgroundColor: '#DCFCE7',
  },
  typeBadgeText: {
    fontSize: 11,
    fontWeight: '700',
  },
  lostText: {
    color: '#DC2626',
  },
  foundText: {
    color: '#16A34A',
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 12,
    gap: 4,
  },
  statusBadgeText: {
    fontSize: 11,
    fontWeight: '700',
  },
  itemTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0F172A',
    marginBottom: 4,
  },
  itemSubtitle: {
    fontSize: 13,
    color: '#64748B',
    marginTop: 2,
  },
});
