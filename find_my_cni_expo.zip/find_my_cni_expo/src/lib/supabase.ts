import 'react-native-url-polyfill/auto';
import { createClient } from '@supabase/supabase-js';
import * as SecureStore from 'expo-secure-store';
import * as FileSystem from 'expo-file-system';
import { decode } from 'base64-arraybuffer';

// CORRIGÉ: Configuration Supabase avec vos identifiants exacts
const SUPABASE_URL = 'https://ccmrkmbmnzriitoiorpj.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_xujLlTyg3-GEx20n8ZsK2Q_8GvYh_CO';

// CORRIGÉ: Adaptateur de stockage persistant et sécurisé compatible Expo / React Native
const ExpoSecureStoreAdapter = {
  getItem: (key: string) => {
    return SecureStore.getItemAsync(key);
  },
  setItem: (key: string, value: string) => {
    return SecureStore.setItemAsync(key, value);
  },
  removeItem: (key: string) => {
    return SecureStore.deleteItemAsync(key);
  },
};

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    storage: ExpoSecureStoreAdapter,
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
  },
});

export interface Declaration {
  id?: string;
  user_id?: string;
  type: 'lost' | 'found'; // 'lost' = Perte, 'found' = CNI Trouvée
  full_name: string;
  date_of_birth?: string;
  cni_last_4_digits?: string;
  location: string;
  contact_phone?: string;
  description?: string;
  photo_url?: string;
  status: 'pending' | 'approved' | 'rejected'; // CORRIGÉ: Toujours 'pending' à la soumission
  created_at?: string;
}

/**
 * CORRIGÉ: Upload de photo vers le bucket Supabase 'cni-photos'
 * Destination structurée strictement: 'cni-photos' / user_id / nom_fichier
 * Utilise Base64 -> ArrayBuffer pour garantir la compatibilité React Native sans erreur Blob/FormData
 */
export async function uploadImageToSupabase(
  uri: string,
  userId: string
): Promise<string | null> {
  try {
    if (!uri) return null;

    // 1. Lire le fichier local en base64
    const base64 = await FileSystem.readAsStringAsync(uri, {
      encoding: FileSystem.EncodingType.Base64,
    });

    const fileExt = uri.split('.').pop()?.toLowerCase() || 'jpg';
    const fileName = `${Date.now()}_${Math.random().toString(36).substring(7)}.${fileExt}`;
    
    // CORRIGÉ: Chemin dans le bucket 'cni-photos' : userId/nom_fichier
    const filePath = `${userId}/${fileName}`;
    const contentType = fileExt === 'png' ? 'image/png' : 'image/jpeg';

    const { data, error } = await supabase.storage
      .from('cni-photos') // CORRIGÉ: Bucket obligatoire
      .upload(filePath, decode(base64), {
        contentType,
        upsert: true,
      });

    if (error) {
      console.error('Erreur Supabase Storage upload:', error.message);
      return null;
    }

    // Récupération de l'URL publique
    const { data: publicUrlData } = supabase.storage
      .from('cni-photos')
      .getPublicUrl(filePath);

    return publicUrlData.publicUrl;
  } catch (err) {
    console.error("Erreur lors de l'upload:", err);
    return null;
  }
}
